# Timeline IE

A Pen created on CodePen.

Original URL: [https://codepen.io/alvarotrigo/pen/yLzBJaN](https://codepen.io/alvarotrigo/pen/yLzBJaN).

