# Responsive Timeline

A Pen created on CodePen.

Original URL: [https://codepen.io/alvarotrigo/pen/VwMZjjQ](https://codepen.io/alvarotrigo/pen/VwMZjjQ).

